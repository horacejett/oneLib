from onelib_ragas.llms.base import RagasLLM
from onelib_ragas.llms.langchain import LangchainLLM
from onelib_ragas.llms.llamaindex import LlamaIndexLLM
from onelib_ragas.llms.openai import OpenAI

__all__ = ["RagasLLM", "LangchainLLM", "LlamaIndexLLM", "llm_factory", "OpenAI"]


def llm_factory(model="gpt-4-1106-preview") -> RagasLLM:
    return OpenAI(model=model)
